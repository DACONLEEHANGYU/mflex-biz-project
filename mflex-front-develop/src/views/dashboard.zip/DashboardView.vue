<template>
  <section class="contents-wrap dashboard">
    <div class="content-box">
      <div class="content-area">
        <div class="content-row">
          <div class="bg-box">
            <div class="dash-main">대시보드</div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script setup></script>
